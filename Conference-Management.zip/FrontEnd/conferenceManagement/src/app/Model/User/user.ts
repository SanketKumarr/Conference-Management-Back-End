export class User {
    user_Id?:number
    name?:string
    email?:string
    password?:string
    designation?:string
    isAdmin?:boolean
}
