﻿- Commands {IRequest}
    - AddHallCommand
    - UpdateHallCommand
    - DeleteRoomCommand

  - Queries {IRequest}
    - DisplayAllRoomQuery
  
- Handlers {IRequestHandler}
    - AddHallCommandHandler
    - UpdateRoomCommandHandler
    - DeleteRoomCommandHandler
